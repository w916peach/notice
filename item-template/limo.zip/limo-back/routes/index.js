/*
 * @Author: mikey.zhaopeng 
 * @Date: 2018-10-21 13:01:28 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2018-10-21 13:01:49
 * @func: 除用户以外的接口
 */
var express = require('express');
var router = express.Router();



module.exports = router;

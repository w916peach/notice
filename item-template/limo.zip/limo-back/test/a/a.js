var path = require('path');
var b = require('../b/b.js');
var c = require('./c.js');
console.log(c);
console.log(b);
console.log(path.resolve('./'));
console.log(process.cwd());